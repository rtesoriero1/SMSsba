package com.Tesoriero.SMS.TesorieroSMS;

import static org.junit.Assert.assertEquals;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import com.Tesoriero.SMS.jpa.entitymodels.Student;
import com.Tesoriero.SMS.jpa.util.HibernateUtil;

/**
 * This classes tests the getStudentFromEmail method found in the StudentDAO
 *
 */
public class GetStudentFromEmailTest {


	/**
	 * This method both establishes a connection to the database and provides use with the "actual" student that will be compared to the "expected" student in the test
	 *
	 */
	
@BeforeEach
public static Student beforeEachMethod(String email) {
	Session session = HibernateUtil.getConnection();
	
	Student actual = new Student();
	
	String hql = "FROM Student s WHERE email = :email";
	TypedQuery query = session.createQuery(hql);
	query.setParameter("email", email);
	actual = (Student) query.getSingleResult();
		
	return actual;
}

/**
 * This method constructed the "expected" student and uses beforeEachMethod to generate the "actual" student via search of the expected student's email.
 *
 */
	
	@Test
	public void getStudentByEmail() {
	
	Student expected = new Student();
		
	String expectedEmail = "htaffley6@columbia.edu";
	String expectedName = "Holmes Taffley";
	String expectedPassword ="xowtOQ";
	
	expected.setsEmail(expectedEmail);
	expected.setsName(expectedName);
	expected.setsPass(expectedPassword);
	
	Student actual =beforeEachMethod(expectedEmail);
	
	
	/**
	 * This part confirms that the "expected student" on line 54 and the "actual student" pulled from the database
	 * are in fact the same before comparing their Name, Email, and Password. 
	 */
	
	assertEquals(actual.getsName(), expected.getsName());
	assertEquals(actual.getsEmail(), expected.getsEmail());
	assertEquals(actual.getsPass(), expected.getsPass());
	
	
	
	
}
}
	


