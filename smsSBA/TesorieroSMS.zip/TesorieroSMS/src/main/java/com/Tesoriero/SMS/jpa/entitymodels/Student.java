package com.Tesoriero.SMS.jpa.entitymodels;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


/**
 * @author Robert Tesoriero 
 * 
 * The purpose of this class is to carry the data related to one student. 
 * Column names are set up to ensure that the provided SQL scripts will insert data without error. 
 *
 */
@Entity
@Table
public class Student implements Serializable {
	private static final long serialVersionUID = 1L;
	
//Setting primary key, no @GeneratedValue since sEmail does not need to be auto-incremented 	
@Id
@Column(name = "email")
private String sEmail;

@Column(name = "name")
private String sName;

@Column(name = "password")
private String sPass; 
	


@ManyToMany(targetEntity = Course.class)
private Set<Course> courseSet;




public Student() {
	this.sEmail = "";
	this.sName = "";
	this.sPass = "";
	
}

public Student(String sEmail, String sName, String sPass) {
	super();
	this.sEmail = sEmail;
	this.sName = sName;
	this.sPass = sPass;
}

public String getsEmail() {
	return sEmail;
}

public void setsEmail(String sEmail) {
	this.sEmail = sEmail;
}

public String getsName() {
	return sName;
}

public void setsName(String sName) {
	this.sName = sName;
}

public String getsPass() {
	return sPass;
}

public void setsPass(String sPass) {
	this.sPass = sPass;
}

@Override
public String toString() {
	return "Student [sEmail=" + sEmail + ", sName=" + sName + ", sPass=" + sPass + "]";
}




}

