package com.Tesoriero.SMS.jpa.entitymodels;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Robert Tesoriero 
 * 
 * The purpose of this class is to carry the data related to one course. 
 * Column names are set up to ensure that the provided SQL scripts will insert data without error. 
 *
 */

@Entity
@Table
public class Course implements Serializable {
	private static final long serialVersionUID = 1L;
	
/**
 * Setting primary key and using @GeneratedValue to auto-increment 
 */
	
@Id
@GeneratedValue (strategy = GenerationType.IDENTITY)	
@Column (name = "id")
private int cId;

@Column (name = "name")
private String cName;

@Column (name = "instructor")
private String cInstructorName;

public Course() {
	this.cId = 0; 
	this.cName = "";
	this.cInstructorName = "";
}

public Course(int cId, String cName, String cInstructorName) {
	super();
	this.cId = cId;
	this.cName = cName;
	this.cInstructorName = cInstructorName;
}

public int getcId() {
	return cId;
}

public void setcId(int cId) {
	this.cId = cId;
}

public String getcName() {
	return cName;
}

public void setcName(String cName) {
	this.cName = cName;
}

public String getcInstructorName() {
	return cInstructorName;
}

public void setcInstructorName(String cInstructorName) {
	this.cInstructorName = cInstructorName;
}

@Override
public String toString() {
	return "Course [cId=" + cId + ", cName=" + cName + ", cInstructorName=" + cInstructorName + "]";
}



}
