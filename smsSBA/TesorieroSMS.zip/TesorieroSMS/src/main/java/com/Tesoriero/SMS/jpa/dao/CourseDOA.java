package com.Tesoriero.SMS.jpa.dao;

import java.util.List;

import com.Tesoriero.SMS.jpa.entitymodels.Course;

/**
 * This interface contains abstract Course Method that will be implemented in the Course Service class
 *
 */
public interface CourseDOA {

	
	
	
	List<Course> getAllCourses();
	
	Course getCoursebyID( int cId);	
	}

