package com.Tesoriero.SMS.jpa.service;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;

import com.Tesoriero.SMS.jpa.dao.CourseDOA;
import com.Tesoriero.SMS.jpa.entitymodels.Course;
import com.Tesoriero.SMS.jpa.entitymodels.Student;
import com.Tesoriero.SMS.jpa.util.HibernateUtil;

/**
 * This class implements the methods constructed in CourseDAO 
 */
public class CourseService implements CourseDOA {

	
	/**
	 * This provides a list of all courses so that the User may select which course they wish to register for. 
	 */		
	
	
	@Override
	public List<Course> getAllCourses() {
		Session session = HibernateUtil.getConnection();
		String hql = "FROM Course ";
		
		TypedQuery<Course> query = session.createQuery(hql, Course.class);
		List<Course> result = query.getResultList();
		for (Course c: result) {
			System.out.println("Course ID: " + c.getcId());
			System.out.println("Course Name: " + c.getcName());
			System.out.println("Course Instructor: " + c.getcInstructorName());
			System.out.println("");
		
	}
		session.close();
		return result;

}
	
	
	/**
	 * This method will be used as part of Course Registration to select a Course from the getAllCourses list
	 */	
	public Course getCoursebyID( int cId) {
		Session session = HibernateUtil.getConnection();
		String hql = "FROM Course s WHERE id = :id";
		
		TypedQuery query = session.createQuery(hql);
		query.setParameter("id", cId);
		Course result = (Course) query.getSingleResult();
		session.close();
		return result;
	}
	
	
}
