package com.Tesoriero.SMS.jpa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.Tesoriero.SMS.jpa.dao.CourseDOA;
import com.Tesoriero.SMS.jpa.dao.StudentDAO;
import com.Tesoriero.SMS.jpa.entitymodels.Course;
import com.Tesoriero.SMS.jpa.entitymodels.Student;
import com.Tesoriero.SMS.jpa.service.CourseService;
import com.Tesoriero.SMS.jpa.service.StudentService;
import com.Tesoriero.SMS.jpa.util.HibernateUtil;

/**
 * @author Robert Tesoriero
 *
 */
public class SMSRunner {

	/**
	 * Creating Scanner Object so Application can accept User inputs. 
	 */
	Scanner input = new Scanner(System.in);
	
	
	/**
	 * Creating Student object for current user and setting initializing fields that will hold hold User inputs. 
	 */
	Student currentStudent = new Student();
	private String email;
	private String password; 
	
	/**
	 * Creating Course object to be used when Student is registering for course. It will store the Course ID of the selection. 
	 */
	Course selectedCourse = new Course();
	private int cId;
	
	/**
	 * Creating StudentDAO and CourseDAO objects to allow us to access necessary methods for menu. 
	 */
	
	StudentDAO studentDAO = new StudentService();
	CourseDOA courseDAO = new CourseService();
	
	/**
	 * Initializing two lists to be used when register student for course 
	 */
	List<Course> availableCourses;
	List<Course> studentCourses = new ArrayList<Course>();
	
	
	/**
	 * Method that builds and populates the database if it is your first time using the application
	 */
	public void startUp() {
		int selection = 0;
		
		System.out.println("Welcome to the Student Management System!");
		System.out.println("Is this your first time running the application?");
		System.out.println("__________________________");
		System.out.println("1). Yes.");
		System.out.println("2). No.");
		
		
		/**
		 * This accepts and stores the user's choice.
		 */
		
		selection = input.nextInt();
		input.nextLine();
		
		
		/**
		 * This prompts the user to pick again if they make an invalid selection.
		 */
		
		if(selection != 1 && selection != 2) {
			System.out.println("______________________________________");
			System.out.println("***!!INVALID SELECTION. PLEASE TRY AGAIN!!***");
			System.out.println("______________________________________");
			startUp();
		}
		
		switch(selection) {
		case 1: buildDataBase();
		case 2: areYouAStudent();
		}
	}
	
	/**
	 * As per the SBA's minimum required workflow, this method confirms that the user is a Student. 
	 */
	public void areYouAStudent() {
		int selection = 0;
		
		
		System.out.println("Are you a Student?");
		System.out.println("__________________________");
		System.out.println("1). Yes.");
		System.out.println("2). No.");
		
		/**
		 * This accepts and stores the user's choice.
		 */
		
		selection = input.nextInt();
		input.nextLine();
		
		
		/**
		 * This prompts the user to pick again if they make an invalid selection.
		 */
		
		if(selection != 1 && selection != 2) {
			System.out.println("______________________________________");
			System.out.println("***!!INVALID SELECTION. PLEASE TRY AGAIN!!***");
			System.out.println("______________________________________");
			areYouAStudent();
		}
		
		
		switch(selection) {
		case 1: 
			System.out.println("__________________________");
			System.out.println("Please provide your login information! ");
			studentLogin();
		case 2: logout();
		}
	}
	
	
	
	/**
	 * This method populates the database with the required data, so a sql script is not required. 
	 * I was not able to execute the Insertion with only one string, so each row required its own. 
	 */
	
	public void buildDataBase() {
		System.out.println("Attempting to build and populate SMS Database...");
		System.out.println("__________________________");
		String sql = "insert into Student (email, name, password) values ('hluckham0@google.ru', 'Hazel Luckham', 'X1uZcoIh0dj');\r\n";
		String sq2 =  "insert into Student (email, name, password) values ('sbowden1@yellowbook.com', 'Sonnnie Bowden', 'SJc4aWSU');\r\n";
		String sq3 =  "insert into Student (email, name, password) values ('qllorens2@howstuffworks.com', 'Quillan Llorens', 'W6rJuxd');\r\n";
		String sq4 =  "insert into Student (email, name, password) values ('cstartin3@flickr.com', 'Clem Startin', 'XYHzJ1S');\r\n";
		String sq5 =  "insert into Student (email, name, password) values ('tattwool4@biglobe.ne.jp', 'Thornie Attwool', 'Hjt0SoVmuBz');\r\n";
		String sq6 =  "insert into Student (email, name, password) values ('hguerre5@deviantart.com', 'Harcourt Guerre', 'OzcxzD1PGs');\r\n";
		String sq7 =  "insert into Student (email, name, password) values ('htaffley6@columbia.edu', 'Holmes Taffley', 'xowtOQ');\r\n";
		String sq8 =  "insert into Student (email, name, password) values ('aiannitti7@is.gd', 'Alexandra Iannitti', 'TWP4hf5j');\r\n";
		String sq9 =  "insert into Student (email, name, password) values ('ljiroudek8@sitemeter.com', 'Laryssa Jiroudek', 'bXRoLUP');\r\n";
		String sq10 =  "insert into Student (email, name, password) values ('cjaulme9@bing.com', 'Cahra Jaulme', 'FnVklVgC6r6');\r\n";
			
		String sq11 =  "insert into Course (id, name, instructor) values (1, 'English', 'Anderea Scamaden');\r\n";
		String sq12 =  "insert into Course (id, name, instructor) values (2, 'Mathematics', 'Eustace Niemetz');\r\n";
		String sq13 =  "insert into Course (id, name, instructor) values (3, 'Anatomy', 'Reynolds Pastor');\r\n";
		String sq14 =  "insert into Course (id, name, instructor) values (4, 'Organic Chemistry', 'Odessa Belcher');\r\n";
		String sq15 =  "insert into Course (id, name, instructor) values (5, 'Physics', 'Dani Swallow');\r\n";
		String sq16 =  "insert into Course (id, name, instructor) values (6, 'Digital Logic', 'Glenden Reilingen');\r\n";
		String sq17 =  "insert into Course (id, name, instructor) values (7, 'Object Oriented Programming', 'Giselle Ardy');\r\n";
		String sq18 =  "insert into Course (id, name, instructor) values (8, 'Data Structures', 'Carolan Stoller');\r\n";
		String sq19 =  "insert into Course (id, name, instructor) values (9, 'Politics', 'Carmita De Maine');\r\n";
		String sq20 =  "insert into Course (id, name, instructor) values (10, 'Art', 'Kingsly Doxsey');";
		try {
			
			Connection connection = HibernateUtil.setConnection();
			
			PreparedStatement stmt1 = connection.prepareStatement(sql);
			PreparedStatement stmt2 = connection.prepareStatement(sq2);
			PreparedStatement stmt3 = connection.prepareStatement(sq3);
			PreparedStatement stmt4 = connection.prepareStatement(sq4);
			PreparedStatement stmt5 = connection.prepareStatement(sq5);
			PreparedStatement stmt6 = connection.prepareStatement(sq6);
			PreparedStatement stmt7 = connection.prepareStatement(sq7);
			PreparedStatement stmt8 = connection.prepareStatement(sq8);
			PreparedStatement stmt9 = connection.prepareStatement(sq9);
			PreparedStatement stmt10 = connection.prepareStatement(sq10);
			PreparedStatement stmt11 = connection.prepareStatement(sq11);
			PreparedStatement stmt12 = connection.prepareStatement(sq12);
			PreparedStatement stmt13 = connection.prepareStatement(sq13);
			PreparedStatement stmt14 = connection.prepareStatement(sq14);
			PreparedStatement stmt15 = connection.prepareStatement(sq15);
			PreparedStatement stmt16 = connection.prepareStatement(sq16);
			PreparedStatement stmt17 = connection.prepareStatement(sq17);
			PreparedStatement stmt18 = connection.prepareStatement(sq18);
			PreparedStatement stmt19 = connection.prepareStatement(sq19);
			PreparedStatement stmt20 = connection.prepareStatement(sq20);
			
			
			stmt1.executeUpdate();
			stmt2.executeUpdate();
			stmt3.executeUpdate();
			stmt4.executeUpdate();
			stmt5.executeUpdate();
			stmt6.executeUpdate();
			stmt7.executeUpdate();
			stmt8.executeUpdate();
			stmt9.executeUpdate();
			stmt10.executeUpdate();
			stmt11.executeUpdate();
			stmt12.executeUpdate();
			stmt13.executeUpdate();
			stmt14.executeUpdate();
			stmt15.executeUpdate();
			stmt16.executeUpdate();
			stmt17.executeUpdate();
			stmt18.executeUpdate();
			stmt19.executeUpdate();
			stmt20.executeUpdate();
			
			connection.close();
			System.out.println("The SMS Database has been set up for use!");
			System.out.println("__________________________");
			areYouAStudent();
			
			
			/**
			 * This catch detects if the database was already populated and moves the user to the next part of the login process instead.
			 */
			
		} catch (Exception e) {
			System.out.println("Application Detects that Database has already been built and populated.");
			System.out.println("__________________________");
			areYouAStudent();
		}
	}
	
	
	
	/**
	 * Method that prompts current user to enter their login information will will be stored in the fields previously initialized. 
	 */
	public void studentLogin() {
		System.out.println("Enter email: ");
		email = input.nextLine();
		System.out.println("Enter password: ");
		password = input.nextLine();
		
		
		/**
		 * Checks if student exists and is using right password. If the validateStudent method returns true, the Menu will launch otherwise they will be prompted to login again  
		 */
		if(studentDAO.validateStudent(email, password)== true) {
			System.out.println("__________________________");
			System.out.println("Login Successful. Welcome!");
			
			/**
			 * After the information is validated I set the email for the current student for use in class registration method.  
			 */
			currentStudent.setsEmail(email);
			runMenu();
		}else {
			System.out.println("__________________________");
			System.out.println("Incorrect Username or Password, please try again below:");
			studentLogin();
		}
	
	}
	
	/**
	 * This method provides a menu in which a student can make a selection for what action they would like to take
	 */
	
	public void runMenu() {
		int selection = 0;
		
		while(true) {
			
			List<Course> currentCourses = studentDAO.getStudentCourses(currentStudent);
			System.out.println("MY CLASSES:");
		
			if(currentCourses.size() > 0) {
				for(Course c: currentCourses) {
					System.out.println("Course Name: " + c.getcName());
					System.out.println("Course Instructor: " + c.getcInstructorName());
					System.out.println("");
				}
			}else {
				System.out.println("***YOU ARE NOT CURRENTLY ENROLLED IN ANY CLASSES***");
			}
			System.out.println("__________________________");
			System.out.println("What would you like to do? Please choose a number to make a selection:");
			System.out.println("__________________________");
			System.out.println("1. Register to a Class.");
			System.out.println("2. Logout.");
			
			
			/**
			 * This is where we store the User's selection choice
			 */
			selection = input.nextInt();
			input.nextLine();
			
			
			/**
			 * This prompts the user to pick again if they make an invalid selection.
			 */
			
			if(selection != 1 && selection != 2) {
				System.out.println("______________________________________");
				System.out.println("***!!INVALID SELECTION. PLEASE TRY AGAIN!!***");
				System.out.println("______________________________________");
				runMenu();
			}
			
			
			switch(selection) {
			case 1: 
				
				/**
				 * Here I am creating two lists:
				 * The first has all of the available courses, populated using the getAllCoursesMethod. 
				 * The second is only the course the student has selected for registration.
				 * I also remove the courses the student has already enrolled in from the available course list to prevent duplicates. 
				 */
				
				availableCourses = courseDAO.getAllCourses();
				studentCourses = studentDAO.getStudentCourses(currentStudent);
				
				/**
				 * This if statement prevents a Null Pointer Exception error 
				 */
				if(studentCourses != null) {
				availableCourses.removeAll(studentCourses);
				}
				System.out.println("Register to a Class:");
				System.out.println("__________________________");
				
				/**
				 * Here I am displaying the courses for selection
				 */
				for (Course c: availableCourses) {
					System.out.println("Course ID: " + c.getcId());
					System.out.println("Course Name: " + c.getcName());
					System.out.println("Course Instructor: " + c.getcInstructorName());
					System.out.println("");
				}
				System.out.println("");
				System.out.println("Select the ID of the Course you would like to register for:");
				int cSelection = input.nextInt();
				
				/**
				 * Here is a Try/Catch block to account for a user inputting an invalid Course ID 
				 */
				
				try {
				selectedCourse = courseDAO.getCoursebyID(cSelection);
				}catch (Exception c) {
					System.out.println("______________________________________");
					System.out.println("***!!INVALID COURSE ID. PLEASE TRY AGAIN!!***");
					System.out.println("______________________________________");
					runMenu();
				}
				/**
				 * If statement in case a wrong Course ID is put in and the result comes back null
				 */
				if(selectedCourse != null) {
					List<Course> studentCourses = new ArrayList<Course>();
					studentDAO.registerStudentToCourse(currentStudent, selectedCourse);
					studentCourses.add(selectedCourse);
					for(Course c: studentCourses) {
						System.out.println("Course Name: " + c.getcName());
						System.out.println("Course Instructor: " + c.getcInstructorName());
						System.out.println("");}
					runMenu();
				}
				break;
			case 2: logout();
			
			}
		}
		
		
	}
	

	
	/**
	 * This method terminates the application
	 */
	
	public void logout() {
		System.out.println("Thank you. Goodbye!");
		System.exit(0);
		
	}
	
}
