package com.Tesoriero.SMS.jpa;

import org.hibernate.Session;

import com.Tesoriero.SMS.jpa.dao.CourseDOA;
import com.Tesoriero.SMS.jpa.dao.StudentDAO;
import com.Tesoriero.SMS.jpa.entitymodels.Student;
import com.Tesoriero.SMS.jpa.service.CourseService;
import com.Tesoriero.SMS.jpa.service.StudentService;
import com.Tesoriero.SMS.jpa.util.HibernateUtil;

/**
 * Author: Robert Tesoriero
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      	
    	/**
    	 * Instructions:
    	 * Please visit the hibernate.cfg.xml to ensure the information required to connect to the database is accurate, like username and password.
    	 * Please run from App.java 
    	 * No SQL Scripts should be required.
    	 * Answering "Yes" to "Is this your first time running the application?"
    	 * Will result in the required database being made and populated.
    	 *
    	 */	
    	
    	Session session = HibernateUtil.getConnection();
        SMSRunner driver = new SMSRunner();
        driver.startUp();
        session.close();
        
      
    }
}
