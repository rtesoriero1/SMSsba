package com.Tesoriero.SMS.jpa.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


/**
 * //The purpose of this class is to save time when establishing a connection between this app and the database 
 *
 */
public class HibernateUtil {

	public static Session getConnection(){
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		 Session session = factory.openSession();
		return session;
		
	}
	
	
	
	/**
	 * I ended up needing to establish this connection to use SQL syntax for my getStudentCourses method to work instead of hql
	 *
	 */

	public static Connection setConnection() throws SQLException, ClassNotFoundException {
		String url = "jdbc:mysql://localhost:3306/smsdb";
		String user = "root";
		String password = "password";
		
		 Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection connection = DriverManager.getConnection(url, user, password);
		
		return connection;}
	
	
	}
	

