package com.Tesoriero.SMS.jpa.dao;

import java.util.List;

import com.Tesoriero.SMS.jpa.entitymodels.Course;
import com.Tesoriero.SMS.jpa.entitymodels.Student;

/**
 * This interface contains abstract Student Methods that will be implemented in the Student Service class
 *
 */

public interface StudentDAO {

List<Student> getAllStudents(); 	

Student getStudentByEmail(String email);

boolean validateStudent(String email, String password);

void registerStudentToCourse(Student student, Course course);

List<Course>getStudentCourses(Student currentStudent);

}
