package com.Tesoriero.SMS.jpa.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;

import com.Tesoriero.SMS.jpa.dao.StudentDAO;
import com.Tesoriero.SMS.jpa.entitymodels.Course;
import com.Tesoriero.SMS.jpa.entitymodels.Student;
import com.Tesoriero.SMS.jpa.util.HibernateUtil;



/**
 * @The purpose of this class is to implement the abstract methods found in StudentDAO 
 *
 */
public class StudentService implements StudentDAO{

	
	/**
	 * The purpose of this method is to generate a list of all students. 
	 */			
	
	@Override
	public List<Student> getAllStudents() {
		Session session = HibernateUtil.getConnection();
		String hql = "FROM Student s";
		
		TypedQuery<Student> query = session.createQuery(hql, Student.class);
		List<Student> result = query.getResultList();
		
		for (Student s: result) {
			System.out.println(" Student Name: " + s.getsName());
		}
		session.close();
		return result;
	}

	
	/**
	 * This method is able to return a Student object that corresponds to an email input
	 */	
	
	@Override
	public Student getStudentByEmail( String email) {
		Session session = HibernateUtil.getConnection();
		String hql = "FROM Student s WHERE email = :email";
		
		TypedQuery query = session.createQuery(hql);
		query.setParameter("email", email);
		Student result = (Student) query.getSingleResult();
		System.out.println(" Student Name: " + result.getsName());
		session.close();
		return result;
		
	}

	
	/**
	 * The purpose of this method is to check if the user's login credentials are correct. 
	 */
	@Override
	public boolean validateStudent(String email, String password) {
		Session session = HibernateUtil.getConnection();
		String hql = "FROM Student WHERE email = :email"; 
		
		TypedQuery query = session.createQuery(hql);
		query.setParameter("email", email); 
		
		
		/**
		 * The purpose of this try/catch block is to prompt the user to log in again if:
		 * 1.) The provided email is no found in the database and causes an "Entity Not Found Exception"
		 * 2.) The password for the provided email is incorrect.
		 */
		try {
			Student s = (Student) query.getSingleResult();
		
			if(s.getsPass().equals(password) ) {
				session.close();
				return true; 
			}else {
				session.close();
				return false;}
		
		}catch (Exception noEntityFound) {
			session.close();
			return false;
		}
		
		
		
			
		
	}

	/**
	 * The purpose of this method is to enroll a student into a course, and thus add them to the student_course table
	 */	
	
	@Override
	public void registerStudentToCourse(Student student, Course course) {
		
		String sql = "INSERT INTO Student_course (Student_email, courseSet_id) values (?, ?)";
		
		try {
		Connection connection = HibernateUtil.setConnection();
		
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setString(1, student.getsEmail());
		stmt.setInt(2, course.getcId());
		stmt.executeUpdate();
		//connection.close();
		}catch (SQLException e) {
			
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
		
		
		
	}

	
	/**
	 * This method's purpose is to display the courses that the User is currently enrolled in.
	 * I needed SQL Syntax to this to work since I think HQL did not like doing a JOIN with a table I do not have a POJO of. 
	 */
	
	@Override
	public List<Course> getStudentCourses(Student student) {
		List<Course> courseList = new ArrayList<Course>();
	
		String sql = "SELECT c.name, c.instructor "
				+ "FROM Course c "
				+ "JOIN student_course sc ON c.id = sc.courseSet_id "
				+" WHERE sc.student_email = ?";
		
		try {
			Connection connection = HibernateUtil.setConnection();
			
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, student.getsEmail());
			
			ResultSet result = stmt.executeQuery();
			
			/**
			 * Pulling Course Name and Course Instructor from the ResultSet and creating a new Course object
			 * This will allow me to construct a Course List that I can iterate through to display course the student is enrolled in. 
			 */
			
			while(result.next()) {
				
				String courseName = result.getString("name");
				String instructorName = result.getString("instructor"); 
				Course c = new Course(); 
				c.setcName(courseName);
				c.setcInstructorName(instructorName);
				
				courseList.add(c);
			}
	
		connection.close();
		return courseList;
		
		
		} catch (Exception noEntityFound) {
			noEntityFound.printStackTrace();
			System.out.println("Invalid Course ID. Please Try again.");
			
			
			
		}
		return null;
	}

}
